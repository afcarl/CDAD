//
//  ViewController.swift
//  MyReader
//
//  Created by Jocelyn Harrington on 4/28/15.
//  Copyright (c) 2015 cleanmicro. All rights reserved.
//

import UIKit
class ViewController: UIViewController, TTTAttributedLabelDelegate {

    @IBOutlet weak var textLabel: TTTAttributedLabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "CS51 Final Project"
        self.textLabel.delegate = self
        let text = loadLocalText()
        textLabel.text = text
        textLabel.sizeToFit()
        lookupAcronymInText(text)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    func loadLocalText() -> String {
        let path = NSBundle.mainBundle().pathForResource("raw", ofType: "txt")
        var text = String(contentsOfFile: path!, encoding: NSUTF8StringEncoding, error: nil)!
        return text
    }
    
    func lookupAcronymInText(text:String) {
        let components = text.componentsSeparatedByCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        println("\(components)")
        let keyWords = DataHelper.didContainWords(components)
        println("\(keyWords)")
        let attributedString = NSMutableAttributedString(string: text)
        for keyword in keyWords {
            let textRange = text.startIndex..<text.endIndex
            text.enumerateSubstringsInRange(textRange, options: NSStringEnumerationOptions.ByWords, { (substring, substringRange, enclosingRange, stop) -> () in
                let start = distance(text.startIndex, substringRange.startIndex)
                let length = distance(substringRange.startIndex, substringRange.endIndex)
                let range = NSMakeRange(start, length)
                if (substring == keyword) {
                    let url = NSURL(string: "action:///\(keyword)")!
                    self.textLabel.addLinkToURL(url, withRange: range)
                }
            })
        }
    }
    
    func attributedLabel(label: TTTAttributedLabel, didSelectLinkWithURL url: NSURL) {
        let keyword = url.lastPathComponent as String!
        let wordDef = DataHelper.lookupKey(keyword)
        addCategory(keyword, wordDef: wordDef)
    }
    
    func addCategory(key:String, wordDef:String) {
        let title = "Defination for "+key
        var defPopView:UIAlertController = UIAlertController(title: title, message: wordDef, preferredStyle: .Alert)
        var action:UIAlertAction = UIAlertAction(title: "OK", style: .Cancel, handler:nil)
        defPopView.addAction(action)
        self.presentViewController(defPopView, animated: true, completion: nil)
        
    }


}

