//
//  DataHelper.swift
//  MyReader
//
//  Created by Jocelyn Harrington on 4/29/15.
//  Copyright (c) 2015 cleanmicro. All rights reserved.
//

import Foundation

public class DataHelper {
    static var fileName : String = "final"
    static var fileType : String = "json"
    
    internal class func JSONParseDictionary(jsonString: String) -> [String: AnyObject] {
        if let data = jsonString.dataUsingEncoding(NSUTF8StringEncoding) {
            if let dictionary = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions(0), error: nil)  as? [String: AnyObject] {
                return dictionary
            }
        }
        return [String: AnyObject]()
    }
    
    internal class func getRawData() -> String {
        let path = NSBundle.mainBundle().pathForResource(fileName, ofType: fileType)
        var text = String(contentsOfFile: path!, encoding: NSUTF8StringEncoding, error: nil)!
        return text
    }
    
    static var dictionary = DataHelper.JSONParseDictionary(DataHelper.getRawData())
    
    public class func didContainWords(rawTextArray:[String])->[String] {
        var containedWords : [String] = []
        let wordsArray = dictionary.keys.array
        for word in wordsArray {
            var filteredArray = rawTextArray.filter({$0 == word})
            containedWords += filteredArray
        }
        return containedWords
    }
    
    public class func lookupKey(word: String) -> String {
        var wordResult = ""
        if let defArr = dictionary[word] as? [[String:String]] {
            for dict in defArr {
                let wordDef = dict["def"]
                wordResult = wordDef!
            }
        }
        return wordResult
    }
}
